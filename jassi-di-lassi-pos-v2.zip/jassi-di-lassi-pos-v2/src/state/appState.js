export const appState = {
  currentUser: null,
  cart: [],
  currentSection: 'order',
};
